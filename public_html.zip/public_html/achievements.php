<?php
require_once 'config.php';
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Получаем данные
$user_achievements = getUserAchievements($_SESSION['user_id']);
$all_achievements = getAllAchievements();

// Подключаем шаблоны
include 'includes/navbar.php';
include 'includes/sidebar.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои достижения - Корпоративный портал</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .achievement-card {
            transition: transform 0.2s;
        }
        .achievement-card:hover {
            transform: scale(1.03);
        }
        .achievement-icon {
            width: 80px;
            height: 80px;
            object-fit: cover;
        }
        .earned-badge {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .progress {
            height: 10px;
        }
    </style>
</head>
<body>
    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Мои достижения</h2>
            <div>
                <span class="badge bg-primary">Всего баллов: <?= $current_user['points'] ?></span>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Полученные достижения</h5>
            </div>
            <div class="card-body">
                <?php if (empty($user_achievements)): ?>
                    <div class="alert alert-info">У вас пока нет достижений</div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($user_achievements as $achievement): ?>
                            <div class="col-md-4 mb-4">
                                <div class="card h-100 achievement-card">
                                    <div class="card-body text-center position-relative">
                                        <?php if (in_array($achievement['id'], array_column($user_achievements, 'id'))): ?>
                                            <span class="badge bg-success earned-badge">
                                                <i class="bi bi-check-circle"></i> Получено
                                            </span>
                                        <?php endif; ?>
                                        <img src="images/achievements/<?= sanitize($achievement['icon']) ?>" 
                                             alt="<?= sanitize($achievement['name']) ?>" 
                                             class="achievement-icon mb-3">
                                        <h5><?= sanitize($achievement['name']) ?></h5>
                                        <p class="text-muted"><?= sanitize($achievement['description']) ?></p>
                                        <span class="badge bg-primary">+<?= $achievement['points'] ?> баллов</span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Все доступные достижения</h5>
            </div>
            <div class="card-body">
                <?php if (empty($all_achievements)): ?>
                    <div class="alert alert-info">Достижений пока нет</div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th style="width: 80px"></th>
                                    <th>Название</th>
                                    <th>Описание</th>
                                    <th>Баллы</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($all_achievements as $achievement): ?>
                                    <tr>
                                        <td>
                                            <img src="images/achievements/<?= sanitize($achievement['icon']) ?>" 
                                                 alt="<?= sanitize($achievement['name']) ?>" 
                                                 class="achievement-icon">
                                        </td>
                                        <td><?= sanitize($achievement['name']) ?></td>
                                        <td><?= sanitize($achievement['description']) ?></td>
                                        <td>+<?= $achievement['points'] ?></td>
                                        <td>
                                            <?php if (in_array($achievement['id'], array_column($user_achievements, 'id'))): ?>
                                                <span class="badge bg-success">
                                                    <i class="bi bi-check-circle"></i> Получено
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">
                                                    <i class="bi bi-lock"></i> Не получено
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>