<?php
// Определения констант
define('BASE_URL', 'https://' . $_SERVER['HTTP_HOST'] . '/public_html/');
define('ASSETS_URL', BASE_URL . 'assets/');

// Конфигурация базы данных
define('DB_HOST', 'localhost');
define('DB_USER', 'cc35839_corp');
define('DB_PASS', 'AdminAdmin12345'); // Не рекомендуется хранить пароли в открытом виде
define('DB_NAME', 'cc35839_corp');

// Настройки сессии
session_start();

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для проверки авторизации
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Функция для проверки роли администратора
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Функция для защиты от XSS
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
?>