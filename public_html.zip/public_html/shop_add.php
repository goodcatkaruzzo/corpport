<?php
require_once 'config.php';
require_once 'functions.php';

if (!isAdmin()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $description = sanitize($_POST['description']);
    $price = (int)$_POST['price'];
    $stock = (int)$_POST['stock'];
    
    // Валидация
    if (empty($name)) $errors[] = 'Название обязательно';
    if (empty($description)) $errors[] = 'Описание обязательно';
    if ($price <= 0) $errors[] = 'Цена должна быть положительной';
    if ($stock < 0) $errors[] = 'Количество не может быть отрицательным';
    
    // Обработка изображения
    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload = uploadImage($_FILES['image']);
        if ($upload['success']) {
            $image = $upload['filename'];
        } else {
            $errors[] = $upload['error'];
        }
    } else {
        $errors[] = 'Изображение обязательно';
    }
    
    if (empty($errors)) {
        if (addShopItem($name, $description, $price, $stock, $image)) {
            $success = true;
        } else {
            $errors[] = 'Ошибка при добавлении товара';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить товар - Корпоративный портал</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include 'navbar.php'; ?>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <h2>Добавить товар</h2>
        
        <?php if ($success): ?>
            <div class="alert alert-success">Товар успешно добавлен!</div>
            <a href="shop.php" class="btn btn-primary">Вернуться в магазин</a>
        <?php else: ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <?php foreach ($errors as $error): ?>
                        <div><?= $error ?></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="name" class="form-label">Название</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                
                <div class="mb-3">
                    <label for="description" class="form-label">Описание</label>
                    <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="price" class="form-label">Цена (баллы)</label>
                        <input type="number" class="form-control" id="price" name="price" min="1" required>
                    </div>
                    <div class="col-md-6">
                        <label for="stock" class="form-label">Количество</label>
                        <input type="number" class="form-control" id="stock" name="stock" min="0" required>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="image" class="form-label">Изображение</label>
                    <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
                    <div class="form-text">Максимальный размер 2MB. Допустимые форматы: JPG, JPEG, PNG, GIF.</div>
                </div>
                
                <button type="submit" class="btn btn-primary">Добавить товар</button>
                <a href="shop.php" class="btn btn-secondary">Отмена</a>
            </form>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>