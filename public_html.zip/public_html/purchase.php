<?php
require_once 'config.php';
require_once 'functions.php';

// Включим подробное логирование ошибок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Проверка авторизации
if (!isLoggedIn()) {
    header("HTTP/1.1 401 Unauthorized");
    exit(json_encode(['error' => 'Требуется авторизация']));
}

// Проверка метода запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("HTTP/1.1 405 Method Not Allowed");
    exit(json_encode(['error' => 'Неверный метод запроса']));
}

// Получение и валидация данных
$item_id = filter_input(INPUT_POST, 'item_id', FILTER_VALIDATE_INT);
if (!$item_id || $item_id < 1) {
    header("HTTP/1.1 400 Bad Request");
    exit(json_encode(['error' => 'Неверный ID товара']));
}

try {
    // Начинаем транзакцию
    $pdo->beginTransaction();
    
    // 1. Получаем данные о товаре
    $stmt = $pdo->prepare("SELECT * FROM shop_items WHERE id = ? FOR UPDATE");
    $stmt->execute([$item_id]);
    $item = $stmt->fetch();
    
    if (!$item) {
        throw new Exception("Товар не найден");
    }
    
    // 2. Проверяем наличие
    if ($item['stock'] < 1) {
        throw new Exception("Товар закончился");
    }
    
    // 3. Проверяем баланс пользователя
    $user = getCurrentUser();
    if ($user['points'] < $item['price']) {
        throw new Exception("Недостаточно баллов");
    }
    
    // 4. Создаем запись о покупке
    $stmt = $pdo->prepare("INSERT INTO user_purchases (user_id, item_id) VALUES (?, ?)");
    if (!$stmt->execute([$user['id'], $item_id])) {
        throw new Exception("Ошибка при записи покупки");
    }
    
    // 5. Уменьшаем количество товара
    $stmt = $pdo->prepare("UPDATE shop_items SET stock = stock - 1 WHERE id = ?");
    if (!$stmt->execute([$item_id])) {
        throw new Exception("Ошибка при обновлении остатка");
    }
    
    // 6. Списание баллов
    $stmt = $pdo->prepare("UPDATE users SET points = points - ? WHERE id = ?");
    if (!$stmt->execute([$item['price'], $user['id']])) {
        throw new Exception("Ошибка при списании баллов");
    }
    
    // 7. Обновляем сессию
    $_SESSION['points'] = $user['points'] - $item['price'];
    
    // Если все успешно - коммитим
    $pdo->commit();
    
    // Добавляем уведомление
    addNotification($user['id'], "Вы приобрели товар: {$item['name']} за {$item['price']} баллов");
    
    // Возвращаем успешный ответ
    header('Location: shop.php?purchase_success=1');
    exit;

} catch (Exception $e) {
    // Откатываем транзакцию при ошибке
    $pdo->rollBack();
    
    // Логируем ошибку
    error_log("Purchase error: " . $e->getMessage());
    
    // Возвращаем ошибку
    header("HTTP/1.1 500 Internal Server Error");
    exit(json_encode(['error' => $e->getMessage()]));
}